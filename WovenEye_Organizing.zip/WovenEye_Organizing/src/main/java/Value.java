public class Value
{
    public String country;
    public String state;
    public Value(String _id, String _value)
    {
       country = _id;
       state = _value;
    }



}
