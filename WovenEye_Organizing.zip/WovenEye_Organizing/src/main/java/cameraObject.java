public class cameraObject
{
    /*
     * Includes GeoIP maxmind data of camera IPS
     */
    public cameraObject()
    {

    }
}
